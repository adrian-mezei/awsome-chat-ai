"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Comprehend = void 0;
class Comprehend {
    constructor() { }
    async handle(event) {
        return { statusCode: 200, body: 'Hello from Comprehend.' };
    }
}
exports.Comprehend = Comprehend;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcHJlaGVuZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2R1bGVzL0NvbXByZWhlbmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsTUFBYSxVQUFVO0lBQ25CLGdCQUFlLENBQUM7SUFFaEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFVO1FBQ25CLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRSxDQUFDO0lBQy9ELENBQUM7Q0FDSjtBQU5ELGdDQU1DIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIENvbXByZWhlbmQge1xyXG4gICAgY29uc3RydWN0b3IoKSB7fVxyXG5cclxuICAgIGFzeW5jIGhhbmRsZShldmVudDogYW55KSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogMjAwLCBib2R5OiAnSGVsbG8gZnJvbSBDb21wcmVoZW5kLicgfTtcclxuICAgIH1cclxufVxyXG4iXX0=