"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Comprehend = void 0;
const client_comprehend_1 = require("@aws-sdk/client-comprehend");
class Comprehend {
    constructor() {
        this.comprehend = new client_comprehend_1.ComprehendClient({});
    }
    async detectSentiment(request) {
        const dominantLanguage = await this.detectDominantLanguage(request.sourceText);
        if (!dominantLanguage || !dominantLanguage.LanguageCode || !dominantLanguage.Score) {
            throw new Error('Comprehend returned undefined dominant language data.');
        }
        const command = new client_comprehend_1.DetectSentimentCommand({
            Text: request.sourceText,
            LanguageCode: dominantLanguage === null || dominantLanguage === void 0 ? void 0 : dominantLanguage.LanguageCode,
        });
        const result = await this.comprehend.send(command);
        if (!result.Sentiment ||
            !result.SentimentScore ||
            !result.SentimentScore.Positive ||
            !result.SentimentScore.Negative ||
            !result.SentimentScore.Neutral ||
            !result.SentimentScore.Mixed) {
            throw new Error('Comprehend returned undefined sentiment data.');
        }
        return {
            sentiment: result.Sentiment,
            sentimentScore: {
                positive: result.SentimentScore.Positive,
                negative: result.SentimentScore.Negative,
                neutral: result.SentimentScore.Neutral,
                mixed: result.SentimentScore.Mixed,
            },
            dominantLanguage: dominantLanguage.LanguageCode,
            dominantLanguageScore: dominantLanguage.Score,
        };
    }
    async detectDominantLanguage(text) {
        const command = new client_comprehend_1.DetectDominantLanguageCommand({ Text: text });
        const result = await this.comprehend.send(command);
        return result.Languages ? result.Languages[0] : undefined;
    }
}
exports.Comprehend = Comprehend;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcHJlaGVuZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2R1bGVzL0NvbXByZWhlbmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsa0VBQXFIO0FBSXJILE1BQWEsVUFBVTtJQUduQjtRQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxvQ0FBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxPQUEwQjtRQUM1QyxNQUFNLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUvRSxJQUFJLENBQUMsZ0JBQWdCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUU7WUFDaEYsTUFBTSxJQUFJLEtBQUssQ0FBQyx1REFBdUQsQ0FBQyxDQUFDO1NBQzVFO1FBRUQsTUFBTSxPQUFPLEdBQUcsSUFBSSwwQ0FBc0IsQ0FBQztZQUN2QyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVU7WUFDeEIsWUFBWSxFQUFFLGdCQUFnQixhQUFoQixnQkFBZ0IsdUJBQWhCLGdCQUFnQixDQUFFLFlBQVk7U0FDL0MsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVuRCxJQUNJLENBQUMsTUFBTSxDQUFDLFNBQVM7WUFDakIsQ0FBQyxNQUFNLENBQUMsY0FBYztZQUN0QixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUTtZQUMvQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUTtZQUMvQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTztZQUM5QixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUM5QjtZQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQztTQUNwRTtRQUVELE9BQU87WUFDSCxTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQWdCO1lBQ2xDLGNBQWMsRUFBRTtnQkFDWixRQUFRLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRO2dCQUN4QyxRQUFRLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRO2dCQUN4QyxPQUFPLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPO2dCQUN0QyxLQUFLLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLO2FBQ3JDO1lBQ0QsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsWUFBWTtZQUMvQyxxQkFBcUIsRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1NBQ2hELENBQUM7SUFDTixDQUFDO0lBRUQsS0FBSyxDQUFDLHNCQUFzQixDQUFDLElBQVk7UUFDckMsTUFBTSxPQUFPLEdBQUcsSUFBSSxpREFBNkIsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ2xFLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFbkQsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7SUFDOUQsQ0FBQztDQUNKO0FBbERELGdDQWtEQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXByZWhlbmRDbGllbnQsIERldGVjdERvbWluYW50TGFuZ3VhZ2VDb21tYW5kLCBEZXRlY3RTZW50aW1lbnRDb21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LWNvbXByZWhlbmQnO1xyXG5pbXBvcnQgeyBDb21wcmVoZW5kUmVxdWVzdCB9IGZyb20gJy4uL21vZGVscy9Db21wcmVoZW5kUmVxdWVzdCc7XHJcbmltcG9ydCB7IENvbXByZWhlbmRSZXNwb25zZSB9IGZyb20gJy4uL21vZGVscy9Db21wcmVoZW5kUmVzcG9uc2UnO1xyXG5cclxuZXhwb3J0IGNsYXNzIENvbXByZWhlbmQge1xyXG4gICAgcHJpdmF0ZSBjb21wcmVoZW5kOiBDb21wcmVoZW5kQ2xpZW50O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHRoaXMuY29tcHJlaGVuZCA9IG5ldyBDb21wcmVoZW5kQ2xpZW50KHt9KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBkZXRlY3RTZW50aW1lbnQocmVxdWVzdDogQ29tcHJlaGVuZFJlcXVlc3QpOiBQcm9taXNlPENvbXByZWhlbmRSZXNwb25zZT4ge1xyXG4gICAgICAgIGNvbnN0IGRvbWluYW50TGFuZ3VhZ2UgPSBhd2FpdCB0aGlzLmRldGVjdERvbWluYW50TGFuZ3VhZ2UocmVxdWVzdC5zb3VyY2VUZXh0KTtcclxuXHJcbiAgICAgICAgaWYgKCFkb21pbmFudExhbmd1YWdlIHx8ICFkb21pbmFudExhbmd1YWdlLkxhbmd1YWdlQ29kZSB8fCAhZG9taW5hbnRMYW5ndWFnZS5TY29yZSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvbXByZWhlbmQgcmV0dXJuZWQgdW5kZWZpbmVkIGRvbWluYW50IGxhbmd1YWdlIGRhdGEuJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBjb21tYW5kID0gbmV3IERldGVjdFNlbnRpbWVudENvbW1hbmQoe1xyXG4gICAgICAgICAgICBUZXh0OiByZXF1ZXN0LnNvdXJjZVRleHQsXHJcbiAgICAgICAgICAgIExhbmd1YWdlQ29kZTogZG9taW5hbnRMYW5ndWFnZT8uTGFuZ3VhZ2VDb2RlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuY29tcHJlaGVuZC5zZW5kKGNvbW1hbmQpO1xyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICFyZXN1bHQuU2VudGltZW50IHx8XHJcbiAgICAgICAgICAgICFyZXN1bHQuU2VudGltZW50U2NvcmUgfHxcclxuICAgICAgICAgICAgIXJlc3VsdC5TZW50aW1lbnRTY29yZS5Qb3NpdGl2ZSB8fFxyXG4gICAgICAgICAgICAhcmVzdWx0LlNlbnRpbWVudFNjb3JlLk5lZ2F0aXZlIHx8XHJcbiAgICAgICAgICAgICFyZXN1bHQuU2VudGltZW50U2NvcmUuTmV1dHJhbCB8fFxyXG4gICAgICAgICAgICAhcmVzdWx0LlNlbnRpbWVudFNjb3JlLk1peGVkXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ29tcHJlaGVuZCByZXR1cm5lZCB1bmRlZmluZWQgc2VudGltZW50IGRhdGEuJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzZW50aW1lbnQ6IHJlc3VsdC5TZW50aW1lbnQgYXMgYW55LFxyXG4gICAgICAgICAgICBzZW50aW1lbnRTY29yZToge1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpdmU6IHJlc3VsdC5TZW50aW1lbnRTY29yZS5Qb3NpdGl2ZSxcclxuICAgICAgICAgICAgICAgIG5lZ2F0aXZlOiByZXN1bHQuU2VudGltZW50U2NvcmUuTmVnYXRpdmUsXHJcbiAgICAgICAgICAgICAgICBuZXV0cmFsOiByZXN1bHQuU2VudGltZW50U2NvcmUuTmV1dHJhbCxcclxuICAgICAgICAgICAgICAgIG1peGVkOiByZXN1bHQuU2VudGltZW50U2NvcmUuTWl4ZWQsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGRvbWluYW50TGFuZ3VhZ2U6IGRvbWluYW50TGFuZ3VhZ2UuTGFuZ3VhZ2VDb2RlLFxyXG4gICAgICAgICAgICBkb21pbmFudExhbmd1YWdlU2NvcmU6IGRvbWluYW50TGFuZ3VhZ2UuU2NvcmUsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBkZXRlY3REb21pbmFudExhbmd1YWdlKHRleHQ6IHN0cmluZykge1xyXG4gICAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgRGV0ZWN0RG9taW5hbnRMYW5ndWFnZUNvbW1hbmQoeyBUZXh0OiB0ZXh0IH0pO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuY29tcHJlaGVuZC5zZW5kKGNvbW1hbmQpO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0Lkxhbmd1YWdlcyA/IHJlc3VsdC5MYW5ndWFnZXNbMF0gOiB1bmRlZmluZWQ7XHJcbiAgICB9XHJcbn1cclxuIl19