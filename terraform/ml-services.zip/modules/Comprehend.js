"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Comprehend = void 0;
const client_comprehend_1 = require("@aws-sdk/client-comprehend");
class Comprehend {
    constructor() {
        this.comprehend = new client_comprehend_1.ComprehendClient({});
    }
    async detectSentiment(request) {
        var _a, _b, _c, _d;
        const dominantLanguage = await this.detectDominantLanguage(request.sourceText);
        const command = new client_comprehend_1.DetectSentimentCommand({
            Text: request.sourceText,
            LanguageCode: dominantLanguage === null || dominantLanguage === void 0 ? void 0 : dominantLanguage.LanguageCode,
        });
        const result = await this.comprehend.send(command);
        return {
            sentiment: result.Sentiment,
            sentimentScore: {
                positive: (_a = result.SentimentScore) === null || _a === void 0 ? void 0 : _a.Positive,
                negative: (_b = result.SentimentScore) === null || _b === void 0 ? void 0 : _b.Negative,
                neutral: (_c = result.SentimentScore) === null || _c === void 0 ? void 0 : _c.Neutral,
                mixed: (_d = result.SentimentScore) === null || _d === void 0 ? void 0 : _d.Mixed,
            },
            dominantLanguage: dominantLanguage === null || dominantLanguage === void 0 ? void 0 : dominantLanguage.LanguageCode,
            dominantLanguageScore: dominantLanguage === null || dominantLanguage === void 0 ? void 0 : dominantLanguage.Score,
        };
    }
    async detectDominantLanguage(text) {
        const command = new client_comprehend_1.DetectDominantLanguageCommand({ Text: text });
        const result = await this.comprehend.send(command);
        return result.Languages ? result.Languages[0] : undefined;
    }
}
exports.Comprehend = Comprehend;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcHJlaGVuZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2R1bGVzL0NvbXByZWhlbmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsa0VBQXFIO0FBSXJILE1BQWEsVUFBVTtJQUduQjtRQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxvQ0FBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxPQUEwQjs7UUFDNUMsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFL0UsTUFBTSxPQUFPLEdBQUcsSUFBSSwwQ0FBc0IsQ0FBQztZQUN2QyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVU7WUFDeEIsWUFBWSxFQUFFLGdCQUFnQixhQUFoQixnQkFBZ0IsdUJBQWhCLGdCQUFnQixDQUFFLFlBQVk7U0FDL0MsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVuRCxPQUFPO1lBQ0gsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFnQjtZQUNsQyxjQUFjLEVBQUU7Z0JBQ1osUUFBUSxFQUFFLE1BQUEsTUFBTSxDQUFDLGNBQWMsMENBQUUsUUFBUTtnQkFDekMsUUFBUSxFQUFFLE1BQUEsTUFBTSxDQUFDLGNBQWMsMENBQUUsUUFBUTtnQkFDekMsT0FBTyxFQUFFLE1BQUEsTUFBTSxDQUFDLGNBQWMsMENBQUUsT0FBTztnQkFDdkMsS0FBSyxFQUFFLE1BQUEsTUFBTSxDQUFDLGNBQWMsMENBQUUsS0FBSzthQUN0QztZQUNELGdCQUFnQixFQUFFLGdCQUFnQixhQUFoQixnQkFBZ0IsdUJBQWhCLGdCQUFnQixDQUFFLFlBQVk7WUFDaEQscUJBQXFCLEVBQUUsZ0JBQWdCLGFBQWhCLGdCQUFnQix1QkFBaEIsZ0JBQWdCLENBQUUsS0FBSztTQUNqRCxDQUFDO0lBQ04sQ0FBQztJQUVELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxJQUFZO1FBQ3JDLE1BQU0sT0FBTyxHQUFHLElBQUksaURBQTZCLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUNsRSxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRW5ELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQzlELENBQUM7Q0FDSjtBQW5DRCxnQ0FtQ0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wcmVoZW5kQ2xpZW50LCBEZXRlY3REb21pbmFudExhbmd1YWdlQ29tbWFuZCwgRGV0ZWN0U2VudGltZW50Q29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1jb21wcmVoZW5kJztcclxuaW1wb3J0IHsgQ29tcHJlaGVuZFJlcXVlc3QgfSBmcm9tICcuLi9tb2RlbHMvQ29tcHJlaGVuZFJlcXVlc3QnO1xyXG5pbXBvcnQgeyBDb21wcmVoZW5kUmVzcG9uc2UgfSBmcm9tICcuLi9tb2RlbHMvQ29tcHJlaGVuZFJlc3BvbnNlJztcclxuXHJcbmV4cG9ydCBjbGFzcyBDb21wcmVoZW5kIHtcclxuICAgIHByaXZhdGUgY29tcHJlaGVuZDogQ29tcHJlaGVuZENsaWVudDtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLmNvbXByZWhlbmQgPSBuZXcgQ29tcHJlaGVuZENsaWVudCh7fSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZGV0ZWN0U2VudGltZW50KHJlcXVlc3Q6IENvbXByZWhlbmRSZXF1ZXN0KTogUHJvbWlzZTxDb21wcmVoZW5kUmVzcG9uc2U+IHtcclxuICAgICAgICBjb25zdCBkb21pbmFudExhbmd1YWdlID0gYXdhaXQgdGhpcy5kZXRlY3REb21pbmFudExhbmd1YWdlKHJlcXVlc3Quc291cmNlVGV4dCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgRGV0ZWN0U2VudGltZW50Q29tbWFuZCh7XHJcbiAgICAgICAgICAgIFRleHQ6IHJlcXVlc3Quc291cmNlVGV4dCxcclxuICAgICAgICAgICAgTGFuZ3VhZ2VDb2RlOiBkb21pbmFudExhbmd1YWdlPy5MYW5ndWFnZUNvZGUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5jb21wcmVoZW5kLnNlbmQoY29tbWFuZCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNlbnRpbWVudDogcmVzdWx0LlNlbnRpbWVudCBhcyBhbnksXHJcbiAgICAgICAgICAgIHNlbnRpbWVudFNjb3JlOiB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGl2ZTogcmVzdWx0LlNlbnRpbWVudFNjb3JlPy5Qb3NpdGl2ZSxcclxuICAgICAgICAgICAgICAgIG5lZ2F0aXZlOiByZXN1bHQuU2VudGltZW50U2NvcmU/Lk5lZ2F0aXZlLFxyXG4gICAgICAgICAgICAgICAgbmV1dHJhbDogcmVzdWx0LlNlbnRpbWVudFNjb3JlPy5OZXV0cmFsLFxyXG4gICAgICAgICAgICAgICAgbWl4ZWQ6IHJlc3VsdC5TZW50aW1lbnRTY29yZT8uTWl4ZWQsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGRvbWluYW50TGFuZ3VhZ2U6IGRvbWluYW50TGFuZ3VhZ2U/Lkxhbmd1YWdlQ29kZSxcclxuICAgICAgICAgICAgZG9taW5hbnRMYW5ndWFnZVNjb3JlOiBkb21pbmFudExhbmd1YWdlPy5TY29yZSxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGRldGVjdERvbWluYW50TGFuZ3VhZ2UodGV4dDogc3RyaW5nKSB7XHJcbiAgICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBEZXRlY3REb21pbmFudExhbmd1YWdlQ29tbWFuZCh7IFRleHQ6IHRleHQgfSk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5jb21wcmVoZW5kLnNlbmQoY29tbWFuZCk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQuTGFuZ3VhZ2VzID8gcmVzdWx0Lkxhbmd1YWdlc1swXSA6IHVuZGVmaW5lZDtcclxuICAgIH1cclxufVxyXG4iXX0=