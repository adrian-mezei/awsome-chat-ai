"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3 = void 0;
const lib_storage_1 = require("@aws-sdk/lib-storage");
const client_s3_1 = require("@aws-sdk/client-s3");
const uuid_1 = require("uuid");
class S3 {
    constructor() {
        this.bucket = process.env.S3_BUCKET;
    }
    async uploadAudio(data) {
        const parallelUploads3 = new lib_storage_1.Upload({
            client: new client_s3_1.S3Client({}),
            params: {
                Bucket: this.bucket,
                Key: `audio/${(0, uuid_1.v4)()}.mp3`,
                Body: data,
                ContentType: 'audio/mpeg',
            },
        });
        const result = await parallelUploads3.done();
        return result.Location;
    }
}
exports.S3 = S3;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUzMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kdWxlcy9TMy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxzREFBOEM7QUFDOUMsa0RBQWlIO0FBQ2pILCtCQUFvQztBQUVwQyxNQUFhLEVBQUU7SUFHWDtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFVLENBQUM7SUFDekMsQ0FBQztJQUVELEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBMkU7UUFDekYsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLG9CQUFNLENBQUM7WUFDaEMsTUFBTSxFQUFFLElBQUksb0JBQVEsQ0FBQyxFQUFFLENBQUM7WUFDeEIsTUFBTSxFQUFFO2dCQUNKLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtnQkFDbkIsR0FBRyxFQUFFLFNBQVMsSUFBQSxTQUFNLEdBQUUsTUFBTTtnQkFDNUIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsV0FBVyxFQUFFLFlBQVk7YUFDNUI7U0FDSixDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixDQUFDLElBQUksRUFBRSxDQUFDO1FBQzdDLE9BQVEsTUFBK0MsQ0FBQyxRQUFTLENBQUM7SUFDdEUsQ0FBQztDQUNKO0FBckJELGdCQXFCQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFVwbG9hZCB9IGZyb20gJ0Bhd3Mtc2RrL2xpYi1zdG9yYWdlJztcclxuaW1wb3J0IHsgQWJvcnRNdWx0aXBhcnRVcGxvYWRDb21tYW5kLCBDb21wbGV0ZU11bHRpcGFydFVwbG9hZENvbW1hbmRPdXRwdXQsIFMzQ2xpZW50IH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LXMzJztcclxuaW1wb3J0IHsgdjQgYXMgdXVpZHY0IH0gZnJvbSAndXVpZCc7XHJcblxyXG5leHBvcnQgY2xhc3MgUzMge1xyXG4gICAgcHJpdmF0ZSBidWNrZXQ6IHN0cmluZztcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLmJ1Y2tldCA9IHByb2Nlc3MuZW52LlMzX0JVQ0tFVCE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgdXBsb2FkQXVkaW8oZGF0YTogc3RyaW5nIHwgUmVhZGFibGVTdHJlYW08YW55PiB8IEJsb2IgfCBVaW50OEFycmF5IHwgQnVmZmVyIHwgdW5kZWZpbmVkKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgICAgICBjb25zdCBwYXJhbGxlbFVwbG9hZHMzID0gbmV3IFVwbG9hZCh7XHJcbiAgICAgICAgICAgIGNsaWVudDogbmV3IFMzQ2xpZW50KHt9KSxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBCdWNrZXQ6IHRoaXMuYnVja2V0LFxyXG4gICAgICAgICAgICAgICAgS2V5OiBgYXVkaW8vJHt1dWlkdjQoKX0ubXAzYCxcclxuICAgICAgICAgICAgICAgIEJvZHk6IGRhdGEsXHJcbiAgICAgICAgICAgICAgICBDb250ZW50VHlwZTogJ2F1ZGlvL21wZWcnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwYXJhbGxlbFVwbG9hZHMzLmRvbmUoKTtcclxuICAgICAgICByZXR1cm4gKHJlc3VsdCBhcyBDb21wbGV0ZU11bHRpcGFydFVwbG9hZENvbW1hbmRPdXRwdXQpLkxvY2F0aW9uITtcclxuICAgIH1cclxufVxyXG4iXX0=