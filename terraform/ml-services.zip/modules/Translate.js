"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Translate = void 0;
class Translate {
    constructor() { }
    async handle(event) {
        return { statusCode: 200, body: 'Hello from Translate.' };
    }
}
exports.Translate = Translate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVHJhbnNsYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21vZHVsZXMvVHJhbnNsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLE1BQWEsU0FBUztJQUNsQixnQkFBZSxDQUFDO0lBRWhCLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBVTtRQUNuQixPQUFPLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUUsQ0FBQztJQUM5RCxDQUFDO0NBQ0o7QUFORCw4QkFNQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBUcmFuc2xhdGUge1xyXG4gICAgY29uc3RydWN0b3IoKSB7fVxyXG5cclxuICAgIGFzeW5jIGhhbmRsZShldmVudDogYW55KSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogMjAwLCBib2R5OiAnSGVsbG8gZnJvbSBUcmFuc2xhdGUuJyB9O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==