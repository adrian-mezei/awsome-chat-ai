"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Polly = void 0;
const client_polly_1 = require("@aws-sdk/client-polly");
const stream_1 = require("stream");
const S3_1 = require("./S3");
class Polly {
    constructor() {
        this.polly = new client_polly_1.PollyClient({});
        this.s3 = new S3_1.S3();
    }
    async synthesizeSpeech(request) {
        // Voices: https://docs.aws.amazon.com/polly/latest/dg/voicelist.html
        var params = new client_polly_1.SynthesizeSpeechCommand({
            OutputFormat: 'mp3',
            Engine: 'neural',
            Text: request.sourceText,
            VoiceId: 'Aria',
        });
        const pollyResponse = await this.polly.send(params);
        const s3FileUrl = await this.s3.uploadAudio(pollyResponse.AudioStream);
        return {
            // audio: await this.audioToBase64String(pollyResponse),
            audioUrl: s3FileUrl,
        };
    }
    async audioToBase64String(output) {
        let audioBuffer;
        if (output instanceof Buffer) {
            audioBuffer = output;
        }
        else if (output instanceof stream_1.Readable) {
            audioBuffer = await this.streamToBuffer(output);
        }
        else {
            console.error(output);
            throw new Error('Polly returned undefined or not Buffer or not Readable.');
        }
        return audioBuffer.toString('base64');
    }
    async streamToBuffer(stream) {
        return new Promise((resolve, reject) => {
            const _buf = Array();
            stream.on('data', chunk => _buf.push(chunk));
            stream.on('end', () => resolve(Buffer.concat(_buf)));
            stream.on('error', err => reject(`error converting stream - ${err}`));
        });
    }
}
exports.Polly = Polly;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUG9sbHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kdWxlcy9Qb2xseS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSx3REFBNkU7QUFHN0UsbUNBQTBDO0FBRzFDLDZCQUEwQjtBQUUxQixNQUFhLEtBQUs7SUFJZDtRQUNJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSwwQkFBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxPQUFFLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLE9BQXFCO1FBQ3hDLHFFQUFxRTtRQUNyRSxJQUFJLE1BQU0sR0FBRyxJQUFJLHNDQUF1QixDQUFDO1lBQ3JDLFlBQVksRUFBRSxLQUFLO1lBQ25CLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVTtZQUN4QixPQUFPLEVBQUUsTUFBTTtTQUNsQixDQUFDLENBQUM7UUFFSCxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BELE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFdBQWtCLENBQUMsQ0FBQztRQUU5RSxPQUFPO1lBQ0gsd0RBQXdEO1lBQ3hELFFBQVEsRUFBRSxTQUFTO1NBQ3RCLENBQUM7SUFDTixDQUFDO0lBRU8sS0FBSyxDQUFDLG1CQUFtQixDQUFDLE1BQXFDO1FBQ25FLElBQUksV0FBbUIsQ0FBQztRQUN4QixJQUFJLE1BQU0sWUFBWSxNQUFNLEVBQUU7WUFDMUIsV0FBVyxHQUFHLE1BQU0sQ0FBQztTQUN4QjthQUFNLElBQUksTUFBTSxZQUFZLGlCQUFRLEVBQUU7WUFDbkMsV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNuRDthQUFNO1lBQ0gsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN0QixNQUFNLElBQUksS0FBSyxDQUFDLHlEQUF5RCxDQUFDLENBQUM7U0FDOUU7UUFDRCxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVPLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBYztRQUN2QyxPQUFPLElBQUksT0FBTyxDQUFTLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzNDLE1BQU0sSUFBSSxHQUFHLEtBQUssRUFBTyxDQUFDO1lBRTFCLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyRCxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzFFLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztDQUNKO0FBakRELHNCQWlEQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBvbGx5Q2xpZW50LCBTeW50aGVzaXplU3BlZWNoQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1wb2xseSc7XHJcbmltcG9ydCB7IFBvbGx5UmVxdWVzdCB9IGZyb20gJy4uL21vZGVscy9Qb2xseVJlcXVlc3QnO1xyXG5pbXBvcnQgeyBQb2xseVJlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL1BvbGx5UmVzcG9uc2UnO1xyXG5pbXBvcnQgeyBSZWFkYWJsZSwgU3RyZWFtIH0gZnJvbSAnc3RyZWFtJztcclxuaW1wb3J0IHsgU3ludGhlc2l6ZVNwZWVjaENvbW1hbmRPdXRwdXQgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtcG9sbHkvZGlzdC10eXBlcy9jb21tYW5kcyc7XHJcbmltcG9ydCB7IFB1dE9iamVjdEFjbENvbW1hbmQgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtczMvZGlzdC10eXBlcy9jb21tYW5kcyc7XHJcbmltcG9ydCB7IFMzIH0gZnJvbSAnLi9TMyc7XHJcblxyXG5leHBvcnQgY2xhc3MgUG9sbHkge1xyXG4gICAgcHJpdmF0ZSBwb2xseTogUG9sbHlDbGllbnQ7XHJcbiAgICBwcml2YXRlIHMzOiBTMztcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLnBvbGx5ID0gbmV3IFBvbGx5Q2xpZW50KHt9KTtcclxuICAgICAgICB0aGlzLnMzID0gbmV3IFMzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgc3ludGhlc2l6ZVNwZWVjaChyZXF1ZXN0OiBQb2xseVJlcXVlc3QpOiBQcm9taXNlPFBvbGx5UmVzcG9uc2U+IHtcclxuICAgICAgICAvLyBWb2ljZXM6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9wb2xseS9sYXRlc3QvZGcvdm9pY2VsaXN0Lmh0bWxcclxuICAgICAgICB2YXIgcGFyYW1zID0gbmV3IFN5bnRoZXNpemVTcGVlY2hDb21tYW5kKHtcclxuICAgICAgICAgICAgT3V0cHV0Rm9ybWF0OiAnbXAzJyxcclxuICAgICAgICAgICAgRW5naW5lOiAnbmV1cmFsJyxcclxuICAgICAgICAgICAgVGV4dDogcmVxdWVzdC5zb3VyY2VUZXh0LFxyXG4gICAgICAgICAgICBWb2ljZUlkOiAnQXJpYScsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHBvbGx5UmVzcG9uc2UgPSBhd2FpdCB0aGlzLnBvbGx5LnNlbmQocGFyYW1zKTtcclxuICAgICAgICBjb25zdCBzM0ZpbGVVcmwgPSBhd2FpdCB0aGlzLnMzLnVwbG9hZEF1ZGlvKHBvbGx5UmVzcG9uc2UuQXVkaW9TdHJlYW0gYXMgYW55KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLy8gYXVkaW86IGF3YWl0IHRoaXMuYXVkaW9Ub0Jhc2U2NFN0cmluZyhwb2xseVJlc3BvbnNlKSxcclxuICAgICAgICAgICAgYXVkaW9Vcmw6IHMzRmlsZVVybCxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgYXN5bmMgYXVkaW9Ub0Jhc2U2NFN0cmluZyhvdXRwdXQ6IFN5bnRoZXNpemVTcGVlY2hDb21tYW5kT3V0cHV0KTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgICAgICBsZXQgYXVkaW9CdWZmZXI6IEJ1ZmZlcjtcclxuICAgICAgICBpZiAob3V0cHV0IGluc3RhbmNlb2YgQnVmZmVyKSB7XHJcbiAgICAgICAgICAgIGF1ZGlvQnVmZmVyID0gb3V0cHV0O1xyXG4gICAgICAgIH0gZWxzZSBpZiAob3V0cHV0IGluc3RhbmNlb2YgUmVhZGFibGUpIHtcclxuICAgICAgICAgICAgYXVkaW9CdWZmZXIgPSBhd2FpdCB0aGlzLnN0cmVhbVRvQnVmZmVyKG91dHB1dCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihvdXRwdXQpO1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1BvbGx5IHJldHVybmVkIHVuZGVmaW5lZCBvciBub3QgQnVmZmVyIG9yIG5vdCBSZWFkYWJsZS4nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGF1ZGlvQnVmZmVyLnRvU3RyaW5nKCdiYXNlNjQnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGFzeW5jIHN0cmVhbVRvQnVmZmVyKHN0cmVhbTogU3RyZWFtKTogUHJvbWlzZTxCdWZmZXI+IHtcclxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IF9idWYgPSBBcnJheTxhbnk+KCk7XHJcblxyXG4gICAgICAgICAgICBzdHJlYW0ub24oJ2RhdGEnLCBjaHVuayA9PiBfYnVmLnB1c2goY2h1bmspKTtcclxuICAgICAgICAgICAgc3RyZWFtLm9uKCdlbmQnLCAoKSA9PiByZXNvbHZlKEJ1ZmZlci5jb25jYXQoX2J1ZikpKTtcclxuICAgICAgICAgICAgc3RyZWFtLm9uKCdlcnJvcicsIGVyciA9PiByZWplY3QoYGVycm9yIGNvbnZlcnRpbmcgc3RyZWFtIC0gJHtlcnJ9YCkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==