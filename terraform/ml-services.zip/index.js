"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const Comprehend_1 = require("./modules/Comprehend");
const Polly_1 = require("./modules/Polly");
const Translate_1 = require("./modules/Translate");
const comprehend = new Comprehend_1.Comprehend();
const translate = new Translate_1.Translate();
const polly = new Polly_1.Polly();
const handler = async (event, context) => {
    console.log(event);
    if (event.body.length > 200)
        return { statusCode: 400, body: 'Request body too large.' };
    try {
        let responseBody;
        switch (event.requestContext.resourcePath) {
            case '/comprehend':
                responseBody = await comprehend.detectSentiment(JSON.parse(event.body));
                break;
            case '/translate':
                responseBody = await translate.translateText(JSON.parse(event.body));
                break;
            case '/polly':
                responseBody = await polly.synthesizeSpeech(JSON.parse(event.body));
                break;
            default:
                return { statusCode: 400, body: 'Unknown path.' };
        }
        return { statusCode: 200, body: JSON.stringify(responseBody), headers: { 'content-type': 'application/json' } };
    }
    catch (e) {
        console.log(e);
        return { statusCode: 500, body: 'Operation failed.' };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWtEO0FBQ2xELDJDQUF3QztBQUN4QyxtREFBZ0Q7QUFFaEQsTUFBTSxVQUFVLEdBQUcsSUFBSSx1QkFBVSxFQUFFLENBQUM7QUFDcEMsTUFBTSxTQUFTLEdBQUcsSUFBSSxxQkFBUyxFQUFFLENBQUM7QUFDbEMsTUFBTSxLQUFLLEdBQUcsSUFBSSxhQUFLLEVBQUUsQ0FBQztBQUVuQixNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsS0FBVSxFQUFFLE9BQVksRUFBZ0IsRUFBRTtJQUNwRSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25CLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRztRQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRSxDQUFDO0lBRXpGLElBQUk7UUFDQSxJQUFJLFlBQVksQ0FBQztRQUNqQixRQUFRLEtBQUssQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFO1lBQ3ZDLEtBQUssYUFBYTtnQkFDZCxZQUFZLEdBQUcsTUFBTSxVQUFVLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3hFLE1BQU07WUFDVixLQUFLLFlBQVk7Z0JBQ2IsWUFBWSxHQUFHLE1BQU0sU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNyRSxNQUFNO1lBQ1YsS0FBSyxRQUFRO2dCQUNULFlBQVksR0FBRyxNQUFNLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNO1lBQ1Y7Z0JBQ0ksT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxDQUFDO1NBQ3pEO1FBQ0QsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsQ0FBQztLQUNuSDtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNmLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxDQUFDO0tBQ3pEO0FBQ0wsQ0FBQyxDQUFDO0FBeEJXLFFBQUEsT0FBTyxXQXdCbEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wcmVoZW5kIH0gZnJvbSAnLi9tb2R1bGVzL0NvbXByZWhlbmQnO1xuaW1wb3J0IHsgUG9sbHkgfSBmcm9tICcuL21vZHVsZXMvUG9sbHknO1xuaW1wb3J0IHsgVHJhbnNsYXRlIH0gZnJvbSAnLi9tb2R1bGVzL1RyYW5zbGF0ZSc7XG5cbmNvbnN0IGNvbXByZWhlbmQgPSBuZXcgQ29tcHJlaGVuZCgpO1xuY29uc3QgdHJhbnNsYXRlID0gbmV3IFRyYW5zbGF0ZSgpO1xuY29uc3QgcG9sbHkgPSBuZXcgUG9sbHkoKTtcblxuZXhwb3J0IGNvbnN0IGhhbmRsZXIgPSBhc3luYyAoZXZlbnQ6IGFueSwgY29udGV4dDogYW55KTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICBjb25zb2xlLmxvZyhldmVudCk7XG4gICAgaWYgKGV2ZW50LmJvZHkubGVuZ3RoID4gMjAwKSByZXR1cm4geyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdSZXF1ZXN0IGJvZHkgdG9vIGxhcmdlLicgfTtcblxuICAgIHRyeSB7XG4gICAgICAgIGxldCByZXNwb25zZUJvZHk7XG4gICAgICAgIHN3aXRjaCAoZXZlbnQucmVxdWVzdENvbnRleHQucmVzb3VyY2VQYXRoKSB7XG4gICAgICAgICAgICBjYXNlICcvY29tcHJlaGVuZCc6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgY29tcHJlaGVuZC5kZXRlY3RTZW50aW1lbnQoSlNPTi5wYXJzZShldmVudC5ib2R5KSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICcvdHJhbnNsYXRlJzpcbiAgICAgICAgICAgICAgICByZXNwb25zZUJvZHkgPSBhd2FpdCB0cmFuc2xhdGUudHJhbnNsYXRlVGV4dChKU09OLnBhcnNlKGV2ZW50LmJvZHkpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJy9wb2xseSc6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgcG9sbHkuc3ludGhlc2l6ZVNwZWVjaChKU09OLnBhcnNlKGV2ZW50LmJvZHkpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnVW5rbm93biBwYXRoLicgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBzdGF0dXNDb2RlOiAyMDAsIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlQm9keSksIGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiAnT3BlcmF0aW9uIGZhaWxlZC4nIH07XG4gICAgfVxufTtcbiJdfQ==