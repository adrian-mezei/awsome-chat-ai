"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const Comprehend_1 = require("./modules/Comprehend");
const Polly_1 = require("./modules/Polly");
const Translate_1 = require("./modules/Translate");
const handler = async (event, context) => {
    console.log(event);
    const comprehend = new Comprehend_1.Comprehend();
    const translate = new Translate_1.Translate();
    const polly = new Polly_1.Polly();
    try {
        let responseBody;
        switch (event.requestContext.resourcePath) {
            case '/comprehend':
                responseBody = await comprehend.handle(JSON.parse(event.body));
                break;
            case '/translate':
                responseBody = await translate.handle(JSON.parse(event.body));
                break;
            case '/polly':
                responseBody = await polly.synthesizeSpeech(JSON.parse(event.body));
                break;
            default:
                return { statusCode: 400, body: 'Unknown path.' };
        }
        return { statusCode: 200, body: JSON.stringify(responseBody), headers: { 'content-type': 'application/json' } };
    }
    catch (e) {
        console.log(e);
        return { statusCode: 500, body: 'Operation failed.' };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWtEO0FBQ2xELDJDQUF3QztBQUN4QyxtREFBZ0Q7QUFFekMsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBRSxPQUFZLEVBQWdCLEVBQUU7SUFDcEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUVuQixNQUFNLFVBQVUsR0FBRyxJQUFJLHVCQUFVLEVBQUUsQ0FBQztJQUNwQyxNQUFNLFNBQVMsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztJQUNsQyxNQUFNLEtBQUssR0FBRyxJQUFJLGFBQUssRUFBRSxDQUFDO0lBRTFCLElBQUk7UUFDQSxJQUFJLFlBQVksQ0FBQztRQUNqQixRQUFRLEtBQUssQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFO1lBQ3ZDLEtBQUssYUFBYTtnQkFDZCxZQUFZLEdBQUcsTUFBTSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQy9ELE1BQU07WUFDVixLQUFLLFlBQVk7Z0JBQ2IsWUFBWSxHQUFHLE1BQU0sU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxNQUFNO1lBQ1YsS0FBSyxRQUFRO2dCQUNULFlBQVksR0FBRyxNQUFNLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNO1lBQ1Y7Z0JBQ0ksT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxDQUFDO1NBQ3pEO1FBQ0QsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsQ0FBQztLQUNuSDtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNmLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxDQUFDO0tBQ3pEO0FBQ0wsQ0FBQyxDQUFDO0FBM0JXLFFBQUEsT0FBTyxXQTJCbEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wcmVoZW5kIH0gZnJvbSAnLi9tb2R1bGVzL0NvbXByZWhlbmQnO1xuaW1wb3J0IHsgUG9sbHkgfSBmcm9tICcuL21vZHVsZXMvUG9sbHknO1xuaW1wb3J0IHsgVHJhbnNsYXRlIH0gZnJvbSAnLi9tb2R1bGVzL1RyYW5zbGF0ZSc7XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBhbnksIGNvbnRleHQ6IGFueSk6IFByb21pc2U8YW55PiA9PiB7XG4gICAgY29uc29sZS5sb2coZXZlbnQpO1xuXG4gICAgY29uc3QgY29tcHJlaGVuZCA9IG5ldyBDb21wcmVoZW5kKCk7XG4gICAgY29uc3QgdHJhbnNsYXRlID0gbmV3IFRyYW5zbGF0ZSgpO1xuICAgIGNvbnN0IHBvbGx5ID0gbmV3IFBvbGx5KCk7XG5cbiAgICB0cnkge1xuICAgICAgICBsZXQgcmVzcG9uc2VCb2R5O1xuICAgICAgICBzd2l0Y2ggKGV2ZW50LnJlcXVlc3RDb250ZXh0LnJlc291cmNlUGF0aCkge1xuICAgICAgICAgICAgY2FzZSAnL2NvbXByZWhlbmQnOlxuICAgICAgICAgICAgICAgIHJlc3BvbnNlQm9keSA9IGF3YWl0IGNvbXByZWhlbmQuaGFuZGxlKEpTT04ucGFyc2UoZXZlbnQuYm9keSkpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnL3RyYW5zbGF0ZSc6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgdHJhbnNsYXRlLmhhbmRsZShKU09OLnBhcnNlKGV2ZW50LmJvZHkpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJy9wb2xseSc6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgcG9sbHkuc3ludGhlc2l6ZVNwZWVjaChKU09OLnBhcnNlKGV2ZW50LmJvZHkpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnVW5rbm93biBwYXRoLicgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBzdGF0dXNDb2RlOiAyMDAsIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlQm9keSksIGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiAnT3BlcmF0aW9uIGZhaWxlZC4nIH07XG4gICAgfVxufTtcbiJdfQ==