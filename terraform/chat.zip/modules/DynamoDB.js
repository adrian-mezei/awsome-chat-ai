"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDB = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class DynamoDB {
    constructor() {
        this.ddb = lib_dynamodb_1.DynamoDBDocument.from(new client_dynamodb_1.DynamoDB({}));
        this.tableName = process.env.TABLE_NAME;
    }
    async put(connectionId) {
        const putParams = {
            TableName: this.tableName,
            Item: { connectionId },
        };
        await this.ddb.put(putParams);
    }
    async delete(connectionId) {
        const deleteParams = {
            TableName: this.tableName,
            Key: { connectionId },
        };
        await this.ddb.delete(deleteParams);
    }
    async scan() {
        return this.ddb.scan({ TableName: this.tableName });
    }
}
exports.DynamoDB = DynamoDB;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRHluYW1vREIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kdWxlcy9EeW5hbW9EQi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw4REFBbUU7QUFDbkUsd0RBQTRFO0FBRTVFLE1BQWEsUUFBUTtJQUlqQjtRQUNJLElBQUksQ0FBQyxHQUFHLEdBQUcsK0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksMEJBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFXLENBQUM7SUFDN0MsQ0FBQztJQUVELEtBQUssQ0FBQyxHQUFHLENBQUMsWUFBb0I7UUFDMUIsTUFBTSxTQUFTLEdBQUc7WUFDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7WUFDekIsSUFBSSxFQUFFLEVBQUUsWUFBWSxFQUFFO1NBQ3pCLENBQUM7UUFFRixNQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFRCxLQUFLLENBQUMsTUFBTSxDQUFDLFlBQW9CO1FBQzdCLE1BQU0sWUFBWSxHQUFHO1lBQ2pCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixHQUFHLEVBQUUsRUFBRSxZQUFZLEVBQUU7U0FDeEIsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELEtBQUssQ0FBQyxJQUFJO1FBQ04sT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUN4RCxDQUFDO0NBQ0o7QUE5QkQsNEJBOEJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRHluYW1vREIgYXMgQVdTRHluYW1vREIgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtZHluYW1vZGInO1xyXG5pbXBvcnQgeyBEeW5hbW9EQkRvY3VtZW50LCBTY2FuQ29tbWFuZE91dHB1dCB9IGZyb20gJ0Bhd3Mtc2RrL2xpYi1keW5hbW9kYic7XHJcblxyXG5leHBvcnQgY2xhc3MgRHluYW1vREIge1xyXG4gICAgcHJpdmF0ZSBkZGI6IER5bmFtb0RCRG9jdW1lbnQ7XHJcbiAgICBwcml2YXRlIHRhYmxlTmFtZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLmRkYiA9IER5bmFtb0RCRG9jdW1lbnQuZnJvbShuZXcgQVdTRHluYW1vREIoe30pKTtcclxuICAgICAgICB0aGlzLnRhYmxlTmFtZSA9IHByb2Nlc3MuZW52LlRBQkxFX05BTUUhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIHB1dChjb25uZWN0aW9uSWQ6IHN0cmluZykge1xyXG4gICAgICAgIGNvbnN0IHB1dFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgVGFibGVOYW1lOiB0aGlzLnRhYmxlTmFtZSxcclxuICAgICAgICAgICAgSXRlbTogeyBjb25uZWN0aW9uSWQgfSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBhd2FpdCB0aGlzLmRkYi5wdXQocHV0UGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBkZWxldGUoY29ubmVjdGlvbklkOiBzdHJpbmcpIHtcclxuICAgICAgICBjb25zdCBkZWxldGVQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIFRhYmxlTmFtZTogdGhpcy50YWJsZU5hbWUsXHJcbiAgICAgICAgICAgIEtleTogeyBjb25uZWN0aW9uSWQgfSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBhd2FpdCB0aGlzLmRkYi5kZWxldGUoZGVsZXRlUGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBzY2FuKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmRkYi5zY2FuKHsgVGFibGVOYW1lOiB0aGlzLnRhYmxlTmFtZSB9KTtcclxuICAgIH1cclxufVxyXG4iXX0=