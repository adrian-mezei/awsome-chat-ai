"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const Handler_1 = require("./modules/Handler");
const handler = async (event, context) => {
    console.log(event);
    const cid = event.requestContext.connectionId;
    const handler = new Handler_1.Handler();
    try {
        switch (event.requestContext.routeKey) {
            case '$connect':
                await handler.connect(cid);
                break;
            case '$disconnect':
                await handler.disconnect(cid);
                break;
            default:
                await handler.default(cid, event.body);
                break;
        }
        return { statusCode: 200, body: 'Data sent.' };
    }
    catch (e) {
        console.log(e);
        return { statusCode: 500, body: 'Operation failed.' };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0NBQTRDO0FBRXJDLE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBRSxLQUFVLEVBQUUsT0FBWSxFQUFnQixFQUFFO0lBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFbkIsTUFBTSxHQUFHLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUM7SUFDOUMsTUFBTSxPQUFPLEdBQUcsSUFBSSxpQkFBTyxFQUFFLENBQUM7SUFFOUIsSUFBSTtRQUNBLFFBQVEsS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUU7WUFDbkMsS0FBSyxVQUFVO2dCQUNYLE1BQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDM0IsTUFBTTtZQUNWLEtBQUssYUFBYTtnQkFDZCxNQUFNLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzlCLE1BQU07WUFDVjtnQkFDSSxNQUFNLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkMsTUFBTTtTQUNiO1FBRUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxDQUFDO0tBQ2xEO0lBQUMsT0FBTyxDQUFDLEVBQUU7UUFDUixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2YsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLENBQUM7S0FDekQ7QUFDTCxDQUFDLENBQUM7QUF4QlcsUUFBQSxPQUFPLFdBd0JsQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhhbmRsZXIgfSBmcm9tICcuL21vZHVsZXMvSGFuZGxlcic7XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBhbnksIGNvbnRleHQ6IGFueSk6IFByb21pc2U8YW55PiA9PiB7XG4gICAgY29uc29sZS5sb2coZXZlbnQpO1xuXG4gICAgY29uc3QgY2lkID0gZXZlbnQucmVxdWVzdENvbnRleHQuY29ubmVjdGlvbklkO1xuICAgIGNvbnN0IGhhbmRsZXIgPSBuZXcgSGFuZGxlcigpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgc3dpdGNoIChldmVudC5yZXF1ZXN0Q29udGV4dC5yb3V0ZUtleSkge1xuICAgICAgICAgICAgY2FzZSAnJGNvbm5lY3QnOlxuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZXIuY29ubmVjdChjaWQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnJGRpc2Nvbm5lY3QnOlxuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZXIuZGlzY29ubmVjdChjaWQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBhd2FpdCBoYW5kbGVyLmRlZmF1bHQoY2lkLCBldmVudC5ib2R5KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7IHN0YXR1c0NvZGU6IDIwMCwgYm9keTogJ0RhdGEgc2VudC4nIH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiAnT3BlcmF0aW9uIGZhaWxlZC4nIH07XG4gICAgfVxufTtcbiJdfQ==